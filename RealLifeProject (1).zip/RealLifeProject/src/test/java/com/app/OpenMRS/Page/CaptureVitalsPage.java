package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.testng.asserts.SoftAssert;

import com.app.OpenMRS.utilities.configs;

public class CaptureVitalsPage {
	@FindBy(xpath = "//input[@id='username']")
	WebElement username;

	@FindBy(xpath = "//input[@id='password']")
	WebElement passwd;

	@FindBy(xpath = "//ul[@id=\"sessionLocation\"]/descendant::li[1]")
	WebElement Location;

	@FindBy(xpath = "//input[@class='btn confirm']")
	WebElement Submit;

	@FindBy(xpath = "//div[@id='body-wrapper']/descendant::a[3]")
	WebElement CaptureVitals;

	@FindBy(xpath = "//input[@id='patient-search']")
	WebElement Searching;

	@FindBy(xpath = "//div[@id='patient-search-results-table_wrapper']/descendant::td[1]")
	WebElement Selecting;

	@FindBy(xpath = "//i[@class='icon-arrow-right']")
	WebElement RecordVitals;

	@FindBy(xpath = "(//input[@type='text'])[2]")
	WebElement Height;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Weight;

	@FindBy(xpath = "(//input[@type='text'])[3]")
	WebElement Weight;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Calculate_BMI;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Temperature;

	@FindBy(xpath = "(//input[@type='text'])[4]")
	WebElement Temperature;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Pulse;

	@FindBy(xpath = "(//input[@type='text'])[5]")
	WebElement Pulse;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Respiratory_Rate;

	@FindBy(xpath = "(//input[@type='text'])[6]")
	WebElement Respiratory_Rate;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Blood_Pressure;

	@FindBy(xpath = "(//input[@type='text'])[7]")
	WebElement Blood_Pressure_Prefix;

	@FindBy(xpath = "(//input[@type='text'])[8]")
	WebElement Blood_Pressure_Sufix;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Pulse_Oximeter;

	@FindBy(xpath = "(//input[@type='text'])[9]")
	WebElement Pulse_Oximeter;

	@FindBy(xpath = "//icon[@class='fas fa-chevron-right']")
	WebElement Next_Confirm;

	@FindBy(xpath = "//button[@type='submit']")
	WebElement Save;
	
	@FindBy(xpath ="//h2[contains(text(),'Capture Vitals for Patient')]")
	WebElement text;

	public CaptureVitalsPage(WebDriver driver) {

		PageFactory.initElements(driver, this);
	}

	public void login() {
		String uname = configs.getUname();
		username.sendKeys(uname);
		String pwd = configs.getPwd();
		passwd.sendKeys(pwd);
	}

	public void location() {

		Location.click();
	}

	public void Submit() {

		Submit.click();
		/*
		 * SoftAssert sf = new SoftAssert();
		 * 
		 * String expectedtitle = "Login"; String actualtitle = driver.getTitle();
		 * 
		 * 
		 * sf.assertEquals(actualtitle, expectedtitle, "The Title does not match");
		 */
	}

	public void CaptureVitals() {
		CaptureVitals.click();
	}

	public void Searching() throws InterruptedException {
		Searching.sendKeys("100JCL");
		Thread.sleep(3000);

	}

	public void Selecting() throws InterruptedException {
		Selecting.click();

	}

	public void Recordbutton() throws InterruptedException {
		RecordVitals.click();
	}

	public void Vital_Information() {

		Height.sendKeys("175");
		Next_Weight.click();
		Weight.sendKeys("75");
		Next_Calculate_BMI.click();
		Next_Temperature.click();
		Temperature.sendKeys("40");
		Next_Pulse.click();
		Pulse.sendKeys("72");
		Next_Respiratory_Rate.click();
		Respiratory_Rate.sendKeys("15");
		Next_Blood_Pressure.click();
		Blood_Pressure_Prefix.sendKeys("100");
		Blood_Pressure_Sufix.sendKeys("60");
		Next_Pulse_Oximeter.click();
		Pulse_Oximeter.sendKeys("98");
	}

	public void confirm() {
		Next_Confirm.click();
	}

	public void save() {
		Save.click();

	}

}
