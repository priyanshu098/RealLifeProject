package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class LoginPage {
	@FindBy(id="username")
	  WebElement username;
	  
	  @FindBy(id="password")
	  WebElement password;
	  
	  @FindBy(xpath="//li[@id='Inpatient Ward']")
	  WebElement inpatient;
	  
	  @FindBy(xpath="//input[@type = 'submit']")
	  WebElement loginbtn;
	  
	  
	  public LoginPage(WebDriver driver) {
	    PageFactory.initElements(driver, this);
	    
	  }
	  
	  public void user_login(String uname,String pwd)
	  {
	    //String uname=configs.getUname();
	    username.sendKeys(uname);
	    //String pwd=configs.getPwd();
	    password.sendKeys(pwd);
	  }
	  public void selLoc() {
		  inpatient.click();
	  }
	  public void login() {
		    loginbtn.click();
	  }
}
