package com.app.OpenMRS.steps;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.app.OpenMRS.Page.FindPatientPage;
import com.app.OpenMRS.utilities.dataprovider;
import com.app.OpenMRS.utilities.log4j;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class findPatientRecordStep {
	WebDriver driver;
	FindPatientPage fp;
	sharedsteps s;
	private Object[][] testdata;
	static int currentRow=0;
	public findPatientRecordStep(sharedsteps share) {
		this.s=share;
	}
	private Logger logger = LogManager.getLogger(log4j.class);
	@Given("Open OpenMRS website")
	public void open_open_mrs_website() {
		driver = sharedsteps.getDriver();
		 fp = new FindPatientPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		String actual=driver.getTitle();
		String expected="Login";
		Assert.assertEquals(actual,expected,"!!!Title Doesn't match with expected title!!!");
		logger.info("!!!!Entered OpenMRS WebSite!!!!");
	}

	@Then("enter Login details {string} and {string}")
	public void enter_login_details_email(String email, String password) throws IOException {
		testdata=dataprovider.readExcelData();
		email=(String) testdata[currentRow][0];
		password=(String) testdata[currentRow][1];
		fp.enterUname(email,password);
		boolean loginSuccessful = fp.isLoginSuccessful();
		
        Assert.assertTrue(loginSuccessful, "Login was not successful for username: " + email);
        logger.info("!!!!!Entered Login details" + email +" "+ password+"!!!!!");
	}

	@Then("select location details & login")
	public void select_location_details_login() throws InterruptedException {
		fp.selLoc();
		fp.login();
		Thread.sleep(2000);
		logger.info("!!!!Selected Location from the WebSite!!!!");
	}

	@Then("Select findpatient Portal")
	public void select_findpatient_portal() {
		fp.findpatient();
		logger.info("!!!!Finding Patient portal in OpenMRS WebSite!!!!");
	   
	}

	@Then("Enter the patient Id or Name")
	public void enter_the_patient_id_or_name() {
		fp.enterpatient();
		logger.info("!!!!Entering patient details in Find Patient portal!!!!");
	}

	@Then("select the patient to view results")
	public void select_the_patient_to_view_results() throws InterruptedException {
		fp.patientdata();
		logger.info("!!!!Selecting the patient details!!!!");
	}
}
