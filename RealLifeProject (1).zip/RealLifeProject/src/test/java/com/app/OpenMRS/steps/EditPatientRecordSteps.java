package com.app.OpenMRS.steps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.app.OpenMRS.Page.EditPatientRecordPage;
import com.app.OpenMRS.utilities.log4j;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class EditPatientRecordSteps {
	WebDriver driver;
	EditPatientRecordPage ep;
	sharedsteps s;
	public EditPatientRecordSteps(sharedsteps share) {
		this.s=share;
	}
	private Logger logger = LogManager.getLogger(log4j.class);
	@Given("Open  website")
	public void open_website() {
		driver = sharedsteps.getDriver();
		 ep = new EditPatientRecordPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		logger.info("!!!!Entered OpenMRS WebSite!!!!");
	}
	@Then("Enter  details")
	public void enter_details() {
		ep.enterUname();
	}
	@Then("Select  details & login")
	public void select_details_login() throws InterruptedException {
		ep.selLoc();
		ep.login();
		logger.info("!!!!!Entered Login & Location details!!!!!");
	}
	
	@Then("Select find Portal")
	public void select_find_portal() throws InterruptedException {
		ep.findpatient();
	    Thread.sleep(1500);
	    logger.info("!!!!Finding Patient portal in OpenMRS WebSite!!!!");
		
	}
	

	@Then("Select the patient to view results")
	public void select_the_patient_to_view_results() throws InterruptedException {
	    ep.enterpatient();
	    Thread.sleep(2000);
	    
	    ep.patientdata();
	    logger.info("!!!!Entering patient details in Find Patient portal!!!!");
	}

	@Then("Select Edit Registeration Information")
	public void select_edit_registeration_information() {
	    ep.editRegestriation();
	    logger.info("!!!!Selecting edit patient info!!!!");
	}

	@Then("Edit the Address and Save the Form")
	public void edit_the_address_and_save_the_form() throws InterruptedException {
	   ep.updateaddress();
	   logger.info("!!!!Updating address and saving!!!!");
	}

	@Then("Select Confirm Changes")
	public void select_confirm_changes() throws InterruptedException {
	   ep.confirming();
	   logger.info("!!!!Confirming the Changes!!!!");
	}

}
