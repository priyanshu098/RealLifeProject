package com.app.OpenMRS.utilities;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.app.OpenMRS.steps.sharedsteps;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


public class extentReports implements ITestListener {
	ScreenShots screenShot;
	 ExtentReports extent;
	 sharedsteps ss;
	 ExtentTest test; 
	
	    public void onStart(ITestContext context) {
	    	screenShot = new ScreenShots();
	    	System.out.println("Testing Started");
	    	ExtentSparkReporter sparkreport= new ExtentSparkReporter("Report.html");
	    	extent = new ExtentReports();
	    	extent.attachReporter(sparkreport);
	    	test=extent.createTest(context.getName());
	    	
	    }

	 
	    public void onTestStart(ITestResult result) {
	    	 test = extent.createTest(result.getMethod().getMethodName());
	     
	    }

	   
	    public void onTestSuccess(ITestResult result) {
	    	test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " - Test Case Passed", ExtentColor.GREEN));
	    }

	   
	    public void onTestFailure(ITestResult result) {
	      
	    	captureScreenshot(result.getMethod().getMethodName());
	    	/* try{
	        	test.addScreenCaptureFromPath(screenShot.takeScreenshot());
	        	System.out.println("Taking ScreenShot");
	        	test.fail(result.getThrowable());
	        	test.log(Status.FAIL,"!!Failed!!");
	        }catch(IOException e) {
	        	e.printStackTrace();
	        }*/
	    }

	
	    public void onTestSkipped(ITestResult result) {
	    	test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.YELLOW));
	    }

	    public void onFinish(ITestContext context) {
	        extent.flush();
	        try {
	        	Desktop.getDesktop().browse(new File("Report.html").toURI());
	        }catch(IOException e) {
	        	e.printStackTrace();
	        }
	    }
	    private void captureScreenshot(String methodName) {
	        ScreenShots.captureScreenshot(sharedsteps.getDriver(), methodName);
	    }

}
