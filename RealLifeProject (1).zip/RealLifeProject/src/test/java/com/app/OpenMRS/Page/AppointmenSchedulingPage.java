package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.app.OpenMRS.utilities.configs;

public class AppointmenSchedulingPage {
	@FindBy(id="username")
	WebElement username;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(xpath="//li[@id='Inpatient Ward']")
	WebElement InpatientWard;
	
	@FindBy(xpath="//input[@class='btn confirm']")
	WebElement confirm ;
	
	@FindBy(xpath="//a[contains(@href, 'appointmentschedulingui')]")
	WebElement appointment;
	
	@FindBy(xpath="//a[@id='appointmentschedulingui-manageAppointments-app']")
	WebElement manage;
	
	@FindBy(xpath="//div[@id='patient-search-results-table_wrapper']/descendant::td[1]")
	WebElement selpatient;
	
	@FindBy(xpath="//input[@id='patient-search']")
	WebElement search;
	
	
	public AppointmenSchedulingPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	public void enterLoginDetails() {
		String uname=configs.getUname();
	    username.sendKeys(uname);
	    String pwd=configs.getPwd();
	    password.sendKeys(pwd);
	}
	public void choseloc() {
		InpatientWard.click();
	}
	public void login() {
		confirm.click();
	}
	public void appointmentsel(){
		appointment.click();
		/*String expected = "AppointmentScheduling";
		WebElement verify = null;
		@SuppressWarnings("null")
		String actual = verify.getText();
		Assert.assertEquals(expected, actual);

		SoftAssert sf = new SoftAssert();
		boolean Added = verify.isDisplayed();
		sf.assertTrue(Added);
		sf.assertAll();*/
	}
	public void clickmanage() {
		manage.click();
	}
	public void patientdetails() throws InterruptedException {
		search.sendKeys("je");
		Thread.sleep(2000);
		selpatient.click();
	}

}
