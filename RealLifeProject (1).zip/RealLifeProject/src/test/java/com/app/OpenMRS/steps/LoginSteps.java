package com.app.OpenMRS.steps;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.app.OpenMRS.Page.LoginPage;
import com.app.OpenMRS.utilities.configs;
import com.app.OpenMRS.utilities.dataprovider;
import com.app.OpenMRS.utilities.log4j;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class LoginSteps {
	WebDriver driver;
	LoginPage lp;
	configs c;
	sharedsteps s;
	private Object[][] testdata;
	static int currentRow=0;
	public LoginSteps(sharedsteps share) {
		this.s=share;
	}
	private Logger logger = LogManager.getLogger(log4j.class);
	@Given("User opens the Healthcare page in chrome")
	public void user_opens_the_healthcare_page_in_chrome() {
		driver = sharedsteps.getDriver();
		 lp = new LoginPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		String ActualTitle= driver.getTitle();
		String ExpectedTitle= "Login";
		Assert.assertEquals(ActualTitle, ExpectedTitle);
		logger.info("Entered OpenMRS WebSite");
	}

	@Then("User enters Following {string} and {string}")
	public void user_enters_following_username_and_password(String email,String pass) throws IOException {
		testdata=dataprovider.readExcelData();
		email=(String) testdata[currentRow][0];
		pass=(String) testdata[currentRow][1];
	    lp.user_login(email,pass);
	    logger.info("Entered Login details:"+ email +" "+ pass);
	    
	}

	@Then("User choose the Location")
	public void user_choose_the_location() {
		lp.selLoc();
		logger.info("Selected location ");
	    
	}

	@Then("User clicks On login")
	public void user_clicks_on_login() {
	   lp.login();
	   logger.info("Logging IN");
	}

}
