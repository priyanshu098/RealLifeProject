package com.app.OpenMRS.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class configs {
	private static final String CONFIG_FILE_PATH = "C:\\Users\\bhara\\eclipse-workspace\\RealLifeProject\\src\\test\\resources\\config.properties";
    private static Properties properties;

    static {
        try {
            FileInputStream fileInput = new FileInputStream(CONFIG_FILE_PATH);
            properties = new Properties();
            properties.load(fileInput);
            fileInput.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static String getUname() {
    	return properties.getProperty("Username");
    }
    public static String getPwd() {
    	return properties.getProperty("Password");
    }
    public static String getPatientId() {
    	return properties.getProperty("PatientId");
    }
}
