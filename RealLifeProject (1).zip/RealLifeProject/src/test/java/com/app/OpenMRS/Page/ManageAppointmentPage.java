package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.testng.Assert;
//import org.testng.asserts.SoftAssert;

public class ManageAppointmentPage {
//Actions a = new Actions(driver);

	
	@FindBy(xpath="//input[@name='username']")
	WebElement Username;
	
	@FindBy(xpath="//input[@name='password']")
	WebElement Password;
	
	@FindBy(xpath="//li[@id='Inpatient Ward']")
	WebElement Location;
	
	@FindBy(xpath="//input[@id='loginButton']")
	WebElement Submit;
	
	@FindBy(xpath="/html/body/div[1]/div[3]/div[3]/div/a[5]")
	WebElement AppointmentsSchedulling;
	
	@FindBy(xpath="/html/body/div[1]/div[3]/div/div[1]/a")
	WebElement ManageServices;
	
	@FindBy(xpath="/html/body/div/div[3]/div/div[1]/button")
	WebElement AddNewService;
	
	@FindBy(xpath="//input[@id='name-field']")
	WebElement emt;
	
	@FindBy(xpath="//input[@id='name-field']")
	WebElement nameinput;
	
	@FindBy(xpath="//input[@id='duration-field']")
	WebElement duration;
	
	@FindBy(xpath="//input[@id='save-button']")
	WebElement save;
	
	@FindBy(xpath="//h1[contains(text(),'Manage Service Types']")
	WebElement verify;
	
	
	public ManageAppointmentPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
	public void login() {
		Username.sendKeys("admin");
		Password.sendKeys("Admin123");
		
		/*
		 * SoftAssert sf = new SoftAssert();
		 * 
		 * String expectedtitle ="Login"; String actualtitle = driver.getTitle();
		 * sf.assertEquals(actualtitle, expectedtitle, "The title donot match");
		 */
	}
	public void loc() {
		Location.click();
	}
	public void submit() {
		Submit.click();
	}
	
	public void AppointmentsSchedulling() {
		AppointmentsSchedulling.click();
	}
	
	public void ManageServices() {
		ManageServices.click();
	}
	
	public void AddNewService() {
		AddNewService.click();
	}
	
	
	public void AddingNewService() throws InterruptedException {
		
		emt.clear();
		nameinput.sendKeys("general health");
		duration.sendKeys("60");
		
		

	}
	public void saving() throws InterruptedException {
		save.click();
		Thread.sleep(2000);
		
		/*
		 * String expected = "Manage Service Types"; String actual = verify.getText();
		 * Assert.assertEquals(expected, actual);
		 */
	}

}
