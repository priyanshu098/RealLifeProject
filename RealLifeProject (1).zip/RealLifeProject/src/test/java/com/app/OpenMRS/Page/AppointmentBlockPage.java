package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AppointmentBlockPage {
	 WebDriver driver;
	 
	 @FindBy(xpath = "//input[@id='username']")
	 WebElement usernameInput;
    
	 @FindBy(xpath = "//input[@id='password']")
    WebElement passwordInput;
    
    @FindBy(id = "loginButton")
    WebElement loginButton;
    
    @FindBy(xpath="//li[@id='Inpatient Ward']")
	  WebElement inpatient;
     
    @FindBy(linkText = "Appointment Scheduling")
     WebElement appointmentschedulinglink;
     
     @FindBy(id = "appointmentschedulingui-scheduleProviders-app")
      WebElement appointmentproviders;
     
     @FindBy(xpath="//td[@class='fc-day fc-thu fc-widget-content fc-today fc-state-highlight']")
     WebElement dermatology;
     
     @FindBy(linkText="Logout")
     WebElement logout;
       
    public AppointmentBlockPage (WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    public void setUsername() {

        usernameInput.sendKeys("admin");

    }
    public void setPassword() {

        passwordInput.sendKeys("Admin123");

    }
    public void clickLogin() throws InterruptedException {
    	inpatient.click();
        loginButton.click();
        Thread.sleep(2000);
    }
    public void clickAppointmentSchedulinglinkText() {
   	 appointmentschedulinglink.click();
   	appointmentproviders.click();
    }
    public void clickingdermatology() throws InterruptedException {
    	Thread.sleep(2000);
    	dermatology.click();
    }
    public void logginout() {
    	logout.click();
    }

}
