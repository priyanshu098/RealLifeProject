package com.app.OpenMRS.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class dataprovider {
	public static Object[][] readExcelData() throws IOException {
        String filePath = "C:\\Users\\bhara\\Desktop\\Training\\RLL\\LogInDetails.xlsx";
        String sheetName = "Sheet1"; // Change to your sheet name

        FileInputStream fileInputStream = new FileInputStream(new File(filePath));
        Workbook workbook = new XSSFWorkbook(fileInputStream);
        Sheet sheet = workbook.getSheet(sheetName);

        Object[][] data = new Object[sheet.getLastRowNum()][2]; // Assuming two columns for username and password

        for (int i = 0; i < sheet.getLastRowNum(); i++) {
            data[i][0] = sheet.getRow(i + 1).getCell(0).toString(); // Assuming username is in the first column (index 0)
            data[i][1] = sheet.getRow(i + 1).getCell(1).toString(); // Assuming password is in the second column (index 1)
        }

        workbook.close();
        fileInputStream.close();

        return data;
    }

}
