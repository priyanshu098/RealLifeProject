package com.app.OpenMRS.steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class sharedsteps {
	public static WebDriver driver;
	
	public static WebDriver getDriver() {
        return driver;
    }

    @Before
    public static void setupWebDriver() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
    }

	
	/*
	 * @After public static void teardownWebDriver() { if (driver != null) {
	 * driver.quit(); } }
	 */
	 

}
