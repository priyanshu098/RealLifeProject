package com.app.OpenMRS.steps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.app.OpenMRS.Page.AppointmentBlockPage;
import com.app.OpenMRS.utilities.log4j;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AppointmentBlockSteps {
	WebDriver driver;
	 AppointmentBlockPage ap;
	 sharedsteps s;
	 public AppointmentBlockSteps(sharedsteps share) {
			this.s=share;
		}
	 private Logger logger = LogManager.getLogger(log4j.class);
	@Given("I am on the OpenMRS login page")
	public void i_am_on_the_open_mrs_login_page() {
		driver = sharedsteps.getDriver();
		 ap = new  AppointmentBlockPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		logger.info("!!!!Entered OpenMRS WebSite!!!!");
	}

	@When("I log in with valid credentials")
	public void i_log_in_with_valid_credentials() throws InterruptedException {
	  ap.setUsername();
	  ap.setPassword();
	  ap.clickLogin();
	  logger.info("!!!!!Entered Login details and Logged into the WebSite!!!!!");
	}

	@When("I navigate to Appointment Scheduling >> Manage Appointment Blocks")
	public void i_navigate_to_appointment_scheduling_manage_appointment_blocks() {
	    ap.clickAppointmentSchedulinglinkText();
	    logger.info("!!!!!Selecting  Manage Appointment Blocks!!!!!");
	}

	@When("I click on the calendar")
	public void i_click_on_the_calendar() throws InterruptedException {
	    ap.clickingdermatology();
	    logger.info("!!!!!Clicking the calander!!!!!");
	}

	@When("I create an Appointment Block with the following details:")
	public void i_create_an_appointment_block_with_the_following_details() {
		ap.logginout();
		logger.info("!!!!!Creating a Appointment Block!!!!!");
	}

	@Then("the Appointment Block is successfully created")
	public void the_appointment_block_is_successfully_created() {
		System.out.print("Done");
		logger.info("!!!!!Successfully blocked appoinment!!!!!");
	}

}
