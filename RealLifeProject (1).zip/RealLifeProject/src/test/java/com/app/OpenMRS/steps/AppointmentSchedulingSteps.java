package com.app.OpenMRS.steps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.app.OpenMRS.Page.AppointmenSchedulingPage;
import com.app.OpenMRS.utilities.log4j;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class AppointmentSchedulingSteps {
	WebDriver driver;
	sharedsteps s;
	AppointmenSchedulingPage as;
	public AppointmentSchedulingSteps(sharedsteps share) {
		this.s=share;
	}
	private Logger logger = LogManager.getLogger(log4j.class);
	@Given("User enters OpenMRS in chrome")
	public void user_enters_OpenMRS_in_chrome() {
		driver = sharedsteps.driver;
		 as = new AppointmenSchedulingPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		logger.info("!!!!Entered OpenMRS WebSite!!!!");
	}

	@Then("User enters Following Uname and Pwd")
	public void user_enters_following_Uname_and_pwd() {
	    as.enterLoginDetails();
	    logger.info("!!!!!Entered Login details!!!!!");
	}

	@Then("User choose the Loc")
	public void user_choose_the_loc() {
		as.choseloc();
		as.login();
		logger.info("!!!!Selected Location from the WebSite & Logging In!!!!");
	    
	}
	@Then("I go to appointment scheduling")
	public void i_go_to_appointment_scheduling() {
	    as.appointmentsel();
	    logger.info("!!!!Selected Appointment Scheduling!!!!");
	}

	@Then("I go to manage appointment")
	public void i_go_to_manage_appointment() {
		as.clickmanage();
		logger.info("!!!!Selected Managing Appointment!!!!");
	}

	@Then("I search for the patient")
	public void i_search_for_the_patient() throws InterruptedException {
	    as.patientdetails();
	    logger.info("!!!!Searching for a patient!!!!");
	}

}
