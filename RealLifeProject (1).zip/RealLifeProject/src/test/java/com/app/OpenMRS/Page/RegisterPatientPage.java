package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.app.OpenMRS.utilities.configs;

public class RegisterPatientPage {
	@FindBy(id = "username")
    private WebElement enterusername;

    @FindBy(id = "password")
    private WebElement pwd;

    @FindBy(id = "Inpatient Ward")
    private WebElement location;

    @FindBy(id = "loginButton")
    private WebElement login;

    @FindBy(id = "referenceapplication-registrationapp-registerPatient-homepageLink-referenceapplication-registrationapp-registerPatient-homepageLink-extension")
    private WebElement Registerpatient;

    @FindBy(name = "givenName")
    private WebElement Given;

    @FindBy(name = "middleName")
    private WebElement Middle;

    @FindBy(name = "familyName")
    private WebElement Family;

    @FindBy(xpath = "//input[contains(@type,'checkbox')]")
    private WebElement unidentifiedpatient;

    @FindBy(id = "gender-field")
    private WebElement gender;

    @FindBy(xpath = "//button[contains(@class,'confirm right')]")
    private WebElement confrm;

    @FindBy(id = "submit")
    private WebElement confirm;


    @FindBy(id = "breadcrumbs")
    private WebElement REGISTER;

    public RegisterPatientPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void enterusername() {
    	String uname=configs.getUname();
        enterusername.sendKeys(uname);
    }

    public void pwd() {
    	 String passwd=configs.getPwd();
        pwd.sendKeys(passwd);
    }

    public void location() {
        location.click();
    }

    public void clicklogin() {
        login.click();
    }

    public void clickRegisterpatient() {
        Registerpatient.click();
    }

    public void Given() {
        Given.sendKeys("abhi");
    }

    public void Middle() {
        Middle.sendKeys("kalal");
    }

    public void Family() {
        Family.sendKeys("gouds");
    }

    public void clickunidentifiedpatient() {
        unidentifiedpatient.click();
    }

    public void selectMaleGender() {
        Select genderDropdown = new Select(gender);
        genderDropdown.selectByVisibleText("Male");
    }

    public void clickarrow() {
        confrm.click();
    }

    public void clickconfirm() {
        confirm.click();
    }

    public String getREGISTERMsg() {
        return REGISTER.getText();
    }

}
