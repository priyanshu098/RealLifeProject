package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.app.OpenMRS.utilities.configs;

public class EditPatientRecordPage {
	@FindBy(xpath="//input[@id='username']")
	WebElement uname;
	
	@FindBy(xpath="//input[@id='password']")
	WebElement pwd;
	
	@FindBy(xpath="//li[@id='Registration Desk']")
	WebElement location;

	/*
	@FindBy(xpath="//*[@id=\"Allgemeinchirurgie\"]")
	WebElement location;
	*/
	@FindBy(xpath="//input[@id='loginButton']")
	WebElement loginbttn;
	
	@FindBy(xpath="//a[@id='coreapps-activeVisitsHomepageLink-coreapps-activeVisitsHomepageLink-extension']")
	WebElement FindpatientRec;
	
	@FindBy(xpath="//input[@id='patient-search']")
	WebElement enterpatientID;
	
	@FindBy(xpath="//div[@id='patient-search-results-table_wrapper']/descendant::td[1]")
	//@FindBy(xpath="//*[@id=\"content\"]/div[2]/div")
	//@FindBy(xpath="//*[@id=\"patient-search-results-table\"]/tbody/tr/td[1]")
	WebElement patientDetails;
	
	@FindBy(xpath="//*[@id='application.registrationapp.summary.editPatientLink']/div/div[2]")
	WebElement Editregisterationinfo;
	
	@FindBy(xpath="//*[@id=\"contactInfo-edit-link\"]")
	WebElement editoption;
	
	@FindBy(xpath="//*[@id=\"address2\"]")
	WebElement updateaddress;
	
	@FindBy(xpath="//*[@id='next-button']")
	WebElement next;
	
	
	@FindBy(xpath="//*[@id=\"save-form\"]")
	WebElement saveForm;
	
	@FindBy(xpath="//*[@id=\"registration-submit\"]")
	WebElement confirm;
	

	public EditPatientRecordPage(WebDriver driver) {
		PageFactory.initElements(driver,this);
		
	}
	public void enterUname() {
		String Uname=configs.getUname();
	    uname.sendKeys(Uname);
	    String Pwd=configs.getPwd();
	    pwd.sendKeys(Pwd);
	}
	public void selLoc() {
		location.click();
	}
	public void login() throws InterruptedException {
		loginbttn.click();
		/*
		 * String expectedtitle = "Home"; String actualtitle = driver.getTitle();
		 * 
		 * Assert.assertEquals(actualtitle, expectedtitle, "The title do not match");
		 * Thread.sleep(2000);
		 */
	}
	public void findpatient() throws InterruptedException{
		FindpatientRec.click();
		Thread.sleep(1000);
		}
	public void enterpatient() throws InterruptedException {
		enterpatientID.click();
		Thread.sleep(2000);
		enterpatientID.sendKeys("10085A");
		Thread.sleep(1200);
	}
	public void patientdata() throws InterruptedException {
		patientDetails.click();
		Thread.sleep(2000);
		
	}
	public void editRegestriation() {
		Editregisterationinfo.click();
		//Thread.sleep(1000);
		editoption.click();
	}
	public void  updateaddress() throws InterruptedException {
		
		updateaddress.sendKeys("NewDelhi");
		updateaddress.click();
		Thread.sleep(1000);
		next.click();
		Thread.sleep(1000);
	}
	public void confirming() throws InterruptedException {
		saveForm.click();
		Thread.sleep(1000);
		confirm.click();
	}

}
