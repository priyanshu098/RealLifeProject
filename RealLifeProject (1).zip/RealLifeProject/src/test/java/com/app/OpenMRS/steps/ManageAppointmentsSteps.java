package com.app.OpenMRS.steps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;


import com.app.OpenMRS.Page.ManageAppointmentPage;
import com.app.OpenMRS.utilities.log4j;


import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ManageAppointmentsSteps {
	WebDriver driver;
	ManageAppointmentPage ma;
	sharedsteps s;
	public ManageAppointmentsSteps(sharedsteps share) {
		this.s=share;
	}
	 private Logger logger = LogManager.getLogger(log4j.class);
	@Then("I open the OpenMRS Health Page")
	public void I_open_the_OpenMRS_Health_Page() {
		driver = sharedsteps.getDriver();
		 ma = new ManageAppointmentPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		logger.info("!!!!Entered OpenMRS WebSite!!!!");
	}

	@Then("I enter the usernamme as admin and password as Admin123")
	public void I_enter_the_usernamme_as_admin_and_password_as_Admin123() {
	    ma.login();
	    logger.info("!!!!!Entered Login details and Logged into the WebSite!!!!!");
	}

	@When("I Select the location")
	public void I_Select_the_location() {
	    ma.loc();
	    logger.info("!!!!!Selecting the location!!!!!");
	}
	@Then("I click  login")
	public void i_click_login() {
		ma.submit();
	    logger.info("!!!!!Clicking on the Login!!!!!");
	}

	@Then("I click on AppointmentSchedulling block")
	public void I_click_on_AppointmentSchedulling_block() {
	    ma.AppointmentsSchedulling();
	    logger.info("!!!!!Click on the AppointmentSchedulling block!!!!");
	}

	@When("I click on ManageServiceType block")
	public void I_click_on_manageServiceType_block() {
	   ma.ManageServices();
	   logger.info("!!!!!Clicking on the ManageServiceType block!!!!!");
	}

	@Then("I click on NewServiceType button")
	public void I_click_on_NewServiceType_button() {
	  ma.AddNewService();
	  logger.info("!!!!!Click on the NewServiceType button!!!!");
	}

	@Then("I enter name as Name on the page")
	public void I_enter_name_as_Name_on_the_page() throws InterruptedException {
	ma.AddingNewService(); 
	logger.info("!!!!!Adding New Service!!!!");
	}

	@Then("I enter duration as duration on the page")
	public void i_enter_duration_as_duration_on_the_page() {
	    System.out.println("Done");
	}
	@When("I click on save button")
	public void i_click_on_save_button() throws InterruptedException {
		ma.saving();
	}

	@Then("I verify")
	public void I_verify() throws InterruptedException {
		System.out.println("Done");
	}

}
