package com.app.OpenMRS.steps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.app.OpenMRS.Page.CaptureVitalsPage;
import com.app.OpenMRS.utilities.log4j;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class CaptureVitalsStep {
	WebDriver driver;
	CaptureVitalsPage cp;
	sharedsteps s;
	public CaptureVitalsStep(sharedsteps share) {
		this.s=share;
	}
	private Logger logger = LogManager.getLogger(log4j.class);
	@Given("I open the browser and enter the URL")
	public void i_open_the_browser_and_enter_the_url() {
		driver = sharedsteps.getDriver();
		 cp = new CaptureVitalsPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		logger.info("!!!!Entered OpenMRS WebSite!!!!");
	
	}

	@Then("I enter the following username as admin and password as Admin123")
	public void i_enter_the_following_username_as_admin_and_password_as_admin123() {
	    cp.login();
	    logger.info("!!!!!Entered Login details!!!!!");
	}

	@Then("I choose the location")
	public void i_choose_the_location() {
	    cp.location();
	    logger.info("!!!!Selected Location from the WebSite!!!!");
	}

	@Then("I click on the login button")
	public void i_click_on_the_login_button() {
	    cp.Submit();
	    logger.info("!!!!Logged in OpenMRS WebSite!!!!");
	}

	@Then("I click on CaptureVitals")
	public void i_click_on_capture_vitals() {
	   cp.CaptureVitals();
	   logger.info("!!!!Selecting capture vitals in OpenMRS WebSite!!!!");
	}

	@Then("I Search the Patient")
	public void i_search_the_patient() throws InterruptedException {
	    cp.Searching();
	    logger.info("!!!!Searching for patient!!!!");
	}

	@Then("I click on PatientID")
	public void i_click_on_patient_id() throws InterruptedException {
	   cp.Selecting();
	   logger.info("!!!!Selecting Patient Id!!!!");
	}

	@Then("I click on Record button")
	public void i_click_on_record_button() throws InterruptedException {
	  cp.Recordbutton();
	  logger.info("!!!!Clicking on Record button!!!!");
	}

	@Then("I enter the information for vitals")
	public void i_enter_the_information_for_vitals() {
	  cp.Vital_Information();
	  logger.info("!!!!Entering information for vitals!!!!");
	}

	@Then("I click on Confirm button")
	public void i_click_on_confirm_button() {
	    cp.confirm();
	    logger.info("!!!!Confirming Info !!!!");
	}

	@Then("I click save")
	public void i_click_save() {
	   cp.save();
	   logger.info("!!!!Saving the changes!!!!");
	}
}
