package com.app.OpenMRS.steps;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;


import com.app.OpenMRS.Page.RegisterPatientPage;
import com.app.OpenMRS.utilities.log4j;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegisterPatientSteps {
	WebDriver driver;
	RegisterPatientPage rp;
	sharedsteps s;
	public RegisterPatientSteps(sharedsteps share) {
		this.s=share;
	}
	 private Logger logger = LogManager.getLogger(log4j.class);
	@Given("I open the OpenMRS and enter URL")
	public void i_open_the_open_mrs_and_enter_url() {
		driver = sharedsteps.getDriver();
		 rp = new RegisterPatientPage(driver);
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		logger.info("!!!!Entered OpenMRS WebSite!!!!");
	  
	}

	@When("I enter username as admin and password as Admin123")
	public void i_enter_username_as_admin_and_password_as_admin123() {
	    rp.enterusername();
	    rp.pwd();
	    logger.info("!!!!!Entered Login details!!!!!");
	}

	@Then("I click the Inpatient Ward")
	public void i_click_the_inpatient_ward() {
		rp.location();
		logger.info("!!!!!Selected Location from the WebSite!!!!!");
	}

	@Then("I click the login button")
	public void i_click_the_login_button() {
	    rp.clicklogin();
	    logger.info("!!!!! Logged In Successfully!!!!!");
	}

	@Then("I click on Register a patient link")
	public void i_click_on_register_a_patient_link() {
		rp.clickRegisterpatient();
		logger.info("!!!!!click on Register a patient link!!!!!");
	    
	}

	@Then("I will be on Register a patient Page and I capture the title of the Page")
	public void i_will_be_on_register_a_patient_page_and_i_capture_the_title_of_the_page() {
		
	System.out.println("Done");
	}

	@Then("I enter given as abhi and middle as kalal and family name as goud")
	public void i_enter_given_as_abhi_and_middle_as_kalal_and_family_name_as_goud() {
	    rp.Given();
	    rp.Middle();
	    rp.Family();
	    logger.info("!!!!!Entered Given,middle,last name!!!!!");
	}

	@Then("I click on Unidentified Patient checkbox")
	public void i_click_on_unidentified_patient_checkbox() {
	    rp.clickunidentifiedpatient();
	    logger.info("!!!!!click on Unidentified Patient checkbox!!!!!");
	}

	@Then("I click on male")
	public void i_click_on_male() {
	    rp.selectMaleGender();
	    logger.info("!!!!!click on male!!!!!");
	    
	}

	@Then("I click on arrow")
	public void i_click_on_arrow() {
	    rp.clickarrow();
	    logger.info("!!!!!checking on arrow!!!!!");
	}

	@Then("I click on confirm button")
	public void i_click_on_confirm_button() {
	   rp.clickconfirm();
	   logger.info("!!!!!click on confirm button!!!!!");
	}

}
