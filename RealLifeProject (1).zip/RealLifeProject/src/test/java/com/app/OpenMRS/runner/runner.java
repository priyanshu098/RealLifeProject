package com.app.OpenMRS.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="C:\\Users\\bhara\\eclipse-workspace\\RealLifeProject\\src\\test\\resources\\com\\app\\OpenMRS\\features\\ManageAppointments.feature",
					glue= {"com.app.OpenMRS.steps"},
					plugin= {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
							"html:target/NewTestReport.html",
							},
					dryRun=false,
					monochrome=true
					
)
public class runner extends AbstractTestNGCucumberTests {

}
