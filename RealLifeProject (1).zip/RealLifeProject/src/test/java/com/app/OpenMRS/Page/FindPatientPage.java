package com.app.OpenMRS.Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.app.OpenMRS.utilities.configs;



public class FindPatientPage {
	@FindBy(xpath="//input[@id='username']")
	WebElement uname;
	
	@FindBy(xpath="//input[@id='usname']")
	WebElement wrong;
	
	@FindBy(xpath="//input[@id='password']")
	WebElement pwd;
	
	@FindBy(xpath="//li[@id='Inpatient Ward']")
	WebElement location;
	
	@FindBy(xpath="//input[@id='loginButton']")
	WebElement loginbttn;
	
	@FindBy(xpath="//a[@id='coreapps-activeVisitsHomepageLink-coreapps-activeVisitsHomepageLink-extension']")
	WebElement patientRec;
	
	@FindBy(xpath="//input[@id='patient-search']")
	WebElement enterpatient;
	
	@FindBy(xpath="//div[@id='patient-search-results-table_wrapper']/descendant::td[1]")
	WebElement patientDetails;
	
	@FindBy(xpath="//div[@class='col-12 col-sm-12 col-md-12 col-lg-12']")
	WebElement logoff;
	
	public FindPatientPage(WebDriver driver) {
		PageFactory.initElements(driver,this);	
	}
	public void falselogin() {
		wrong.click();
	}
	public void enterUname(String email, String password) {
		uname.sendKeys(email);
		pwd.sendKeys(password);
	}
	public void selLoc() {
		location.click();
	}
	public void login() throws InterruptedException {
		loginbttn.click();
		Thread.sleep(2000);
	}
	public void findpatient() {
		patientRec.click();
	}
	public void enterpatient() {
		enterpatient.click();
		String PatientId=configs.getPatientId();
		enterpatient.sendKeys(PatientId);
	}
	public void patientdata() throws InterruptedException {
		patientDetails.click();
		Thread.sleep(2000);
	}
	 public boolean isLoginSuccessful() {
	        return logoff.isDisplayed();
	    }
}
